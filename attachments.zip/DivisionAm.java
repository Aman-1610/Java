class DivisionAm
{
public static void main(String args[])
{
int a=100;
int b=20;
int c;
c=a/b;
System.out.print("Division of a and b is "+c);
}
}
