class SiAm
{
public static void main(String args[])
{
int p=10000;
float r=6.78f;
int t=6;
float si;
si=(p*r*t)/100;
System.out.print("Simple interest of principle amount is  "+si);
}
}
